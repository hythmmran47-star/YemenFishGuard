#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <RTClib.h>
#include <ESP32Servo.h>
#include <Wire.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* mqtt_server = "broker.emqx.io";

const char* device_id = "BOX-001";
const char* telemetry_topic = "haitham/yemenfish/BOX-001/telemetry";
const char* command_topic = "haitham/yemenfish/BOX-001/command";

WiFiClient espClient;
PubSubClient client(espClient);

#define DHTPIN 15
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

RTC_DS1307 rtc;

#define DOOR_SWITCH_PIN 4
#define SERVO_PIN 18
#define BUZZER_PIN 5
#define COOLING_LED_PIN 2 

Servo doorServo;

unsigned long lastMsgTime = 0;
const long interval = 10000; 
 void setup_wifi() {
  delay(10);
  Serial.print("\n[Wi-Fi] Connecting to: ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    attempts++;
    if (attempts > 20) {
      Serial.println("\n[Wi-Fi] Retrying Connection...");
      WiFi.begin(ssid, password);
      attempts = 0;
    }
  }
  Serial.println("\n[Wi-Fi] Connected successfully!");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());
}

 void callback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  
  Serial.print("[MQTT Inbound] Topic: ");
  Serial.print(topic);
  Serial.print(" | Message: ");
  Serial.println(message);

   if (message.indexOf("\"command\":\"CLOSE_DOOR\"") >= 0) {
    Serial.println("  >>> [ACTUATOR] Command Received: Actuating Servo to CLOSE DOOR");
    doorServo.write(0); 
    digitalWrite(BUZZER_PIN, LOW); 
  } 
  else if (message.indexOf("\"command\":\"COOLING_ON\"") >= 0) {
    Serial.println("  >>> [ACTUATOR] Command Received: Actuating Cooling System ON");
    digitalWrite(COOLING_LED_PIN, HIGH); 
  }
  else if (message.indexOf("\"command\":\"COOLING_OFF\"") >= 0) {
    Serial.println("  >>> [ACTUATOR] Command Received: Actuating Cooling System OFF");
    digitalWrite(COOLING_LED_PIN, LOW); 
  }
}
 
void reconnect() {
  while (!client.connected()) {
    Serial.print("[MQTT] Connecting to broker... ");
    String clientId = "YemenFish-ESP32-";
    clientId += String(random(0xffff), HEX);
    
    if (client.connect(clientId.c_str())) {
      Serial.println("Connected successfully.");
      client.subscribe(command_topic);
      Serial.print("[MQTT] Subscribed to topic: ");
      Serial.println(command_topic);
    } else {
      Serial.print("Internal State: ");
      Serial.println(client.state());
      Serial.println("[MQTT] Failed connection -> Retrying in 5 seconds...");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  
   dht.begin();
  Wire.begin();
  if (!rtc.begin()) {
    Serial.println("Couldn't find RTC");
  }
  if (!rtc.isrunning()) {
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }
  
  pinMode(DOOR_SWITCH_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(COOLING_LED_PIN, OUTPUT);
  
  doorServo.attach(SERVO_PIN);
  doorServo.write(0); 

  setup_wifi();
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  unsigned long now = millis();
  if (now - lastMsgTime > interval) {
    lastMsgTime = now;

     float t = dht.readTemperature();
    float h = dht.readHumidity();
    if (isnan(t) || isnan(h)) {
      t = 24.0;
      h = 40.0;
    }

    bool isDoorOpen = digitalRead(DOOR_SWITCH_PIN) == HIGH;

     DateTime time = rtc.now();
    char timestamp[25];
    snprintf(timestamp, sizeof(timestamp), "%04d-%02d-%02d %02d:%02d:%02d", 
             time.year(), time.month(), time.day(), time.hour(), time.minute(), time.second());

     String payload = "{";
    payload += "\"device_id\":\"" + String(device_id) + "\",";
    payload += "\"temperature\":" + String(t, 1) + ",";
    payload += "\"humidity\":" + String(h, 1) + ",";
    payload += "\"door_open\":" + (isDoorOpen ? String("true") : String("false")) + ",";
    payload += "\"timestamp\":\"" + String(timestamp) + "\"";
    payload += "}";

    Serial.print("[MQTT Outbound] Publishing to ");
    Serial.println(telemetry_topic);
    Serial.println(payload);

    client.publish(telemetry_topic, payload.c_str());
  }
}